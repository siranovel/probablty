#include <stdio.h>
#include <assert.h>
#include "JJFreeChart.h"
#include "JClassLoader.h"

static jobject doNewJFreeChart(JNIEnv* env, jobject loader, jstring title, jobject plot);
static jobject JJFreeChart_doGetXYPlot(JNIEnv* env, jobject chart);
static void JJFreeChart_doAddSubtitle(JNIEnv* env, jobject chart, jobject subtitle);
static JJFreeChart _jJfreeChart = {
	.FP_getXYPlot = JJFreeChart_doGetXYPlot,
	.FP_addSubtitle = JJFreeChart_doAddSubtitle,
};
jobject newJFreeChart(JNIEnv* env, jobject loader, jstring title, jobject plot)
{
	assert(env != 0);
	assert(loader != 0);
	assert(plot != 0);
	return doNewJFreeChart(env, loader, title, plot);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JJFreeChart_getXYPlot(JNIEnv* env, jobject chart)
{
	assert(env != 0);
	assert(chart != 0);
	return _jJfreeChart.FP_getXYPlot(env, chart);
}
void JJFreeChart_addSubtitle(JNIEnv* env, jobject chart, jobject subtitle)
{
	assert(env != 0);
	assert(chart != 0);
	assert(subtitle != 0);
	_jJfreeChart.FP_addSubtitle(env, chart, subtitle);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewJFreeChart(JNIEnv* env, jobject loader, jstring title, jobject plot)
{
	jvalue argValues[] = {
		[0] = { .l = title},
		[1] = { .l = plot},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,JFreeChart));
	
	return JClass_NewObjectA(env, clz, "(Ljava/lang/String;Lorg/jfree/chart/plot/Plot;)V", argValues);
}
static jobject JJFreeChart_doGetXYPlot(JNIEnv* env, jobject chart)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chart), "getXYPlot", "()Lorg/jfree/chart/plot/XYPlot;");
	
	return JClass_CallObjectMethodA(env, chart, mid, 0);
}
static void JJFreeChart_doAddSubtitle(JNIEnv* env, jobject chart, jobject subtitle)
{
	jvalue argValues[] = {
		[0] = { .l = subtitle},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, chart), "addSubtitle", "(Lorg/jfree/chart/title/Title;)V");
	JClass_CallVoidMethodA(env, chart, mid, argValues);
}
