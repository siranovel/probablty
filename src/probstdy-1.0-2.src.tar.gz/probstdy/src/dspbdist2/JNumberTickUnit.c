#include <stdio.h>
#include <assert.h>
#include "JNumberTickUnit.h"
#include "JClassLoader.h"

static jobject doNewNumberTickUnit(JNIEnv* env, jobject loader, double size);
jobject newNumberTickUnit(JNIEnv* env, jobject loader, double size)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewNumberTickUnit(env, loader, size);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewNumberTickUnit(JNIEnv* env, jobject loader, double size)
{
	jvalue argValues[] = {
		[0] = { .d = size},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,NumberTickUnit));
	
	return JClass_NewObjectA(env, clz, "(D)V", argValues);
}
