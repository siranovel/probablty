#ifndef _JNumberTickUnit_H_
#define _JNumberTickUnit_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
/**************************************/
/* define�錾                         */
/**************************************/
#define NumberTickUnit         "org.jfree.chart.axis.NumberTickUnit"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newNumberTickUnit(JNIEnv* env, jobject loader, double size);
#endif
