#ifndef _JXYBarRenderer_H_
#define _JXYBarRenderer_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXYBarRenderer JXYBarRenderer;

struct _JXYBarRenderer
{
	void (*FP_setBaseToolTipGenerator)(JNIEnv* env, jobject renderer, jobject generator);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define XYBarRenderer "org.jfree.chart.renderer.xy.XYBarRenderer"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXYBarRenderer(JNIEnv* env, jobject loader);
void JXYBarRenderer_setBaseToolTipGenerator(JNIEnv* env, jobject renderer, jobject generator);
#endif
