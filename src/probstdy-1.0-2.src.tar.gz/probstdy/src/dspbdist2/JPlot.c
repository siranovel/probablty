#include <stdio.h>
#include <assert.h>
#include "JPlot.h"

static jobject JPloat_doGetRangeAxis(JNIEnv* env, jobject plot, int index);
static jobject JPloat_doGetDomainAxis(JNIEnv* env, jobject plot, int index);
static void JPlot_doMapDatasetToRangeAxis(JNIEnv* env, jobject plot, int index, int axisIndex);
static void JPlot_doSetDatasetRenderingOrder(JNIEnv* env, jobject plot, jobject order);
static JPlot _jPlot = {
	.FP_getRangeAxis = JPloat_doGetRangeAxis,
	.FP_getDomainAxis = JPloat_doGetDomainAxis,
	.FP_mapDatasetToRangeAxis = JPlot_doMapDatasetToRangeAxis,
	.FP_setDatasetRenderingOrder = JPlot_doSetDatasetRenderingOrder,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JPloat_getRangeAxis(JNIEnv* env, jobject plot, int index)
{
	assert(env != 0);
	assert(plot != 0);
	return _jPlot.FP_getRangeAxis(env, plot, index);
}
jobject JPloat_getDomainAxis(JNIEnv* env, jobject plot, int index)
{
	assert(env != 0);
	assert(plot != 0);
	return _jPlot.FP_getDomainAxis(env, plot, index);
}
void JPlot_mapDatasetToRangeAxis(JNIEnv* env, jobject plot, int index, int axisIndex)
{
	assert(env != 0);
	assert(plot != 0);
	return _jPlot.FP_mapDatasetToRangeAxis(env, plot, index, axisIndex);
}
void JPlot_setDatasetRenderingOrder(JNIEnv* env, jobject plot, jobject order)
{
	assert(env != 0);
	assert(plot != 0);
	assert(order != 0);
	_jPlot.FP_setDatasetRenderingOrder(env, plot, order);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JPloat_doGetRangeAxis(JNIEnv* env, jobject plot, int index)
{
	jvalue argValues[] = {
		[0] = { .i = index},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, plot), "getRangeAxis", "(I)Lorg/jfree/chart/axis/ValueAxis;");
	
	return JClass_CallObjectMethodA(env, plot, mid, argValues);
}
static jobject JPloat_doGetDomainAxis(JNIEnv* env, jobject plot, int index)
{
	jvalue argValues[] = {
		[0] = { .i = index},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, plot), "getDomainAxis", "(I)Lorg/jfree/chart/axis/ValueAxis;");
	
	return JClass_CallObjectMethodA(env, plot, mid, argValues);
}
static void JPlot_doMapDatasetToRangeAxis(JNIEnv* env, jobject plot, int index, int axisIndex)
{
	jvalue argValues[] = {
		[0] = { .i = index},
		[1] = { .i = axisIndex},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, plot), "mapDatasetToRangeAxis", "(II)V");
	
	JClass_CallVoidMethodA(env, plot, mid, argValues);
}
static void JPlot_doSetDatasetRenderingOrder(JNIEnv* env, jobject plot, jobject order)
{
	jvalue argValues[] = {
		[0] = { .l = order},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, plot), "setDatasetRenderingOrder", "(Lorg/jfree/chart/plot/DatasetRenderingOrder;)V");
	JClass_CallVoidMethodA(env, plot, mid, argValues);
}
