#include <stdio.h>
#include <assert.h>
#include "JCombinedDomainXYPlot.h"
#include "JClassLoader.h"

static jobject doNewCombinedDomainXYPlot(JNIEnv* env, jobject loader, jobject domainAxis);
static void JCombinedDomainXYPlot_doAdd(JNIEnv* env, jobject combDomPlotObj, jobject subplot, int weight);
static JCombinedDomainXYPlot _jCombDomPlot = {
	.FP_add = JCombinedDomainXYPlot_doAdd,
};
jobject newCombinedDomainXYPlot(JNIEnv* env, jobject loader, jobject domainAxis)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewCombinedDomainXYPlot(env, loader, domainAxis);
}

/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JCombinedDomainXYPlot_add(JNIEnv* env, jobject combDomPlotObj, jobject subplot, int weight)
{
	assert(env != 0);
	assert(combDomPlotObj != 0);
	assert(subplot != 0);
	_jCombDomPlot.FP_add(env, combDomPlotObj, subplot, weight);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewCombinedDomainXYPlot(JNIEnv* env, jobject loader, jobject domainAxis)
{
	jvalue argValues[] = {
		[0] = { .l = domainAxis},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env, CombinedDomainXYPlot));
	
	return JClass_NewObjectA(env, clz, "(Lorg/jfree/chart/axis/ValueAxis;)V", argValues);
}
static void JCombinedDomainXYPlot_doAdd(JNIEnv* env, jobject combDomPlotObj, jobject subplot, int weight)
{
	jvalue argValues[] = {
		[0] = { .l = subplot},
		[1] = { .i = weight},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, combDomPlotObj), "add", "(Lorg/jfree/chart/plot/XYPlot;I)V");
	
	JClass_CallVoidMethodA(env, combDomPlotObj, mid, argValues);
}
