#ifndef _JXIntervalSeries_H_
#define _JXIntervalSeries_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXIntervalSeries JXIntervalSeries;

struct _JXIntervalSeries
{
	void (*FP_add)(JNIEnv* env, jobject series, double x, double xLow, double xHigh, double y);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define XIntervalSeries               "org.jfree.data.xy.XIntervalSeries"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXIntervalSeries(JNIEnv* env, jobject loader, jstring key);
void JXIntervalSeries_add(JNIEnv* env, jobject series, double x, double xLow, double xHigh, double y);
#endif
