#include <stdio.h>
#include <assert.h>
#include "JXYBarRenderer.h"
#include "JClassLoader.h"

static jobject doNewXYBarRenderer(JNIEnv* env, jobject loader);
static void JXYBarRenderer_doSetBaseToolTipGenerator(JNIEnv* env, jobject renderer, jobject generator);
static JXYBarRenderer _jXYBarRender = {
	.FP_setBaseToolTipGenerator = JXYBarRenderer_doSetBaseToolTipGenerator,
};
jobject newXYBarRenderer(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXYBarRenderer(env, loader);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXYBarRenderer_setBaseToolTipGenerator(JNIEnv* env, jobject renderer, jobject generator)
{
	assert(env != 0);
	assert(renderer != 0);
	assert(generator != 0);
	_jXYBarRender.FP_setBaseToolTipGenerator(env, renderer, generator);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXYBarRenderer(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XYBarRenderer));
	
	return JClass_NewObjectA(env, clz, "()V", NULL);
}
static void JXYBarRenderer_doSetBaseToolTipGenerator(JNIEnv* env, jobject renderer, jobject generator)
{
	jvalue argValues[] = {
		[0] = { .l = generator},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, renderer), "setBaseToolTipGenerator", "(Lorg/jfree/chart/labels/XYToolTipGenerator;)V");
	JClass_CallVoidMethodA(env, renderer, mid, argValues);
}

