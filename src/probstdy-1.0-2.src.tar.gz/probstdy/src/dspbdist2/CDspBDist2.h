#ifndef _CDspBDist2_H_
#define _CDspBDist2_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist2 CDspBDist2;
typedef struct _CWeekLawOfLargeNums CWeekLawOfLargeNums;
typedef struct _CBernoulliTrial CBernoulliTrial;

struct _CDspBDist2
{
	int n;
	CBernoulliTrial*     ber;
	CWeekLawOfLargeNums* weekOfNums;
	char (*FP_test)(CDspBDist2* pThis, double x, double sd);
	void (*FP_createChart)(CDspBDist2* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist2* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 1200
#define TIME 1000
#define Mean01    0.1
#define Mean04    0.4
#define Mean09    0.9
#define SD05  0.05
#define SD03  0.03
#define SD01  0.01
#define CLASS_MIN 0.25
#define CLASS_MAX 0.52
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist2* getDspBDist2(char* modPth);
void CDspBDist2_ctor(CDspBDist2* pThis, char* modPth);
void CDspBDist2_dtor(CDspBDist2* pThis);
char CDspBDist2_test(CDspBDist2* pThis, double x, double sd);
void CDspBDist2_createChart(CDspBDist2* pThis);
void CDspBDist2_writeChartAsJPEG(CDspBDist2* pThis, char* fileName);
#endif
