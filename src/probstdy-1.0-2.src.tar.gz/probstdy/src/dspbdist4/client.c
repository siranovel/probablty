#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "CDspBDist4.h"
#include "CRndWal.h"


static void usage();
void dspbdist4(CDspBDist4* pThis);
void calc(CDspBDist4* pThis);
int getRandom(int min, int max);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist4* pThis = getDspBDist4(updModPth);
	
	pThis->n = N;
	if (3 == argc) {
		sscanf(argv[2], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist4(pThis);
	CDspBDist4_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | ���\n", exeNm);
	printf("\n");
	printf("\t0 < ���\tdefault:%d\n", N);
}
void dspbdist4(CDspBDist4* pThis)
{
	calc(pThis);
	CDspBDist4_createChart(pThis);
	CDspBDist4_writeChartAsJPEG(pThis, "rndwalk.jpg");
}
void calc(CDspBDist4* pThis)
{
	CRndWal*     rndwalk = pThis->rndwalk;;
	int i;
	const int sz = sizeof(int) * pThis->n;
	
	rndwalk->p04 = malloc(sz);
	rndwalk->p05 = malloc(sz);
	memset(rndwalk->p04, 0, sz);
	memset(rndwalk->p05, 0, sz);
	srand(time(0));
	int* p04 = rndwalk->p04;
	int* p05 = rndwalk->p05;
	for(i = 0; i < pThis->n; i++) {
		int rnd = getRandom(0, 99);
		
		p04[i] = -1;
		p05[i] = -1;
		if(40 > rnd) {
			p04[i] = 1;
		}
		if(50 > rnd) {
			p05[i] = 1;
		}
	}
}
int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
