#ifndef _JXYSeries_H_
#define _JXYSeries_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXYSeries JXYSeries;

struct _JXYSeries
{
	void (*FP_add)(JNIEnv* env, jobject series, double x, double y);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define XYSeries               "org.jfree.data.xy.XYSeries"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXYSeries(JNIEnv* env, jobject loader, jstring key);
void JXYSeries_add(JNIEnv* env, jobject series, double x, double y);
#endif
