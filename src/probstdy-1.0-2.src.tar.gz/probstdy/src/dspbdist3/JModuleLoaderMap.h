#ifndef _JModuleLoaderMap_H_
#define _JModuleLoaderMap_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JModuleLoaderMap JModuleLoaderMap;

struct _JModuleLoaderMap
{
	jobject (*FP_mappingFunction)(JNIEnv* env, jobject cf);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JModuleLoaderMap_mappingFunction(JNIEnv* env, jobject cf);
#endif
