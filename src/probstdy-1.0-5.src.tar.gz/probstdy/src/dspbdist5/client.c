#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "CDspBDist5.h"


static void usage();
void dspbdist5(CDspBDist5* pThis);
void calc(CDspBDist5* pThis);
int getRandom(int min, int max);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist5* pThis = getDspBDist5(updModPth);
	
	pThis->n = N;
	if (3 == argc) {
		sscanf(argv[2], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist5(pThis);
	CDspBDist5_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | ���\n", exeNm);
	printf("\n");
	printf("\t0 < ��default:%d\n", N);
}
void dspbdist5(CDspBDist5* pThis)
{
	calc(pThis);
	CDspBDist5_createChart(pThis);
	CDspBDist5_writeChartAsJPEG(pThis, "martine.jpg");
}
void calc(CDspBDist5* pThis)
{
	int i;
	const int sz = sizeof(int) * pThis->n;
	CMartinGale* martin = pThis->martin;
	
	martin->z045 = malloc(sz);
	martin->z050 = malloc(sz);
	martin->z055 = malloc(sz);
	memset(martin->z045, 0, sz);
	memset(martin->z050, 0, sz);
	memset(martin->z055, 0, sz);
	int* z045 = martin->z045;
	int* z050 = martin->z050;
	int* z055 = martin->z055;
	srand(time(0));
	for(i = 0; i < pThis->n; i++) {
		int rnd = getRandom(0, 99);
		
		z045[i] = -1;
		z050[i] = -1;
		z055[i] = -1;
		if(45 > rnd) {
			z045[i] = 1;
		}
		if(50 > rnd) {
			z050[i] = 1;
		}
		if(55 > rnd) {
			z055[i] = 1;
		}
	}
}
int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
