#ifndef _CDspBDist5_H_
#define _CDspBDist5_H_

#include "CMartinGale.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist5 CDspBDist5;

struct _CDspBDist5
{
	int n;
	CMartinGale* martin;
	void (*FP_createChart)(CDspBDist5* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist5* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 600
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist5* getDspBDist5(char* modPth);
void CDspBDist5_ctor(CDspBDist5* pThis, char* modPth);
void CDspBDist5_dtor(CDspBDist5* pThis);
void CDspBDist5_createChart(CDspBDist5* pThis);
void CDspBDist5_writeChartAsJPEG(CDspBDist5* pThis, char* fileName);

#endif
