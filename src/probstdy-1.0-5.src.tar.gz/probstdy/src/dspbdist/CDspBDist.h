#ifndef _CDspBDist_H_
#define _CDspBDist_H_

/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 1200
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist CDspBDist;
typedef struct _CBernoulliTrial CBernoulliTrial;

struct _CDspBDist
{
	int n;
	CBernoulliTrial*     ber;
	void (*FP_createChart)(CDspBDist* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist* pThis, char* fileName);
};
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist* getDspBDist(char* modPth);
void CDspBDist_ctor(CDspBDist* pThis, char* modPth);
void CDspBDist_dtor(CDspBDist* pThis);
void CDspBDist_createChart(CDspBDist* pThis);
void CDspBDist_writeChartAsJPEG(CDspBDist* pThis, char* fileName);
#endif
