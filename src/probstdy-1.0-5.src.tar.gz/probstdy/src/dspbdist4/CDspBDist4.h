#ifndef _CDspBDist4_H_
#define _CDspBDist4_H_

#include "CRndWal.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist4 CDspBDist4;

struct _CDspBDist4
{
	int n;
	CRndWal rndwalk[5];
	void (*FP_createChart)(CDspBDist4* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist4* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 1200
#define NTIME(a) NSIZE(a)
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist4* getDspBDist4(char* modPth);
void CDspBDist4_ctor(CDspBDist4* pThis, char* modPth);
void CDspBDist4_dtor(CDspBDist4* pThis);
void CDspBDist4_createChart(CDspBDist4* pThis);
void CDspBDist4_writeChartAsJPEG(CDspBDist4* pThis, char* fileName);

#endif
