#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "CDspBDist4.h"


static void usage();
void dspbdist4(CDspBDist4* pThis);
void calc(CDspBDist4* pThis);
int getRandom(int min, int max);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist4* pThis = getDspBDist4(updModPth);
	
	pThis->n = N;
	if (3 == argc) {
		sscanf(argv[2], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist4(pThis);
	CDspBDist4_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | ���\n", exeNm);
	printf("\n");
	printf("\t0 < ���\tdefault:%d\n", N);
}
void dspbdist4(CDspBDist4* pThis)
{
	calc(pThis);
	CDspBDist4_createChart(pThis);
	CDspBDist4_writeChartAsJPEG(pThis, "rndwalk.jpg");
}
void calc(CDspBDist4* pThis)
{
	int i;
	int j;
	const int sz = sizeof(int) * pThis->n;
	
	srand(time(0));
	for (i = 0; i < NTIME(pThis->rndwalk); i++) {
		CRndWal*     rndwalk = &pThis->rndwalk[i];

		rndwalk->z05 = malloc(sz);
		memset(rndwalk->z05, 0, sz);
		int* z05 = rndwalk->z05;
		for(j = 0; j < pThis->n; j++) {
			int rnd = getRandom(0, 99);
			
			z05[j] = -1;
			if(50 > rnd) {
				z05[j] = 1;
			}
		}
	}
}
int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
