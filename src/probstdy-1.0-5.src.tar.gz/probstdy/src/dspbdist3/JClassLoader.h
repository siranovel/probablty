#ifndef _JClassLoader_H_
#define _JClassLoader_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JClassLoader JClassLoader;

struct _JClassLoader
{
	jclass (*FP_loadClass)(JNIEnv* env, jobject loader, jstring name); 
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jclass JClassLoader_loadClass(JNIEnv* env, jobject loader, jstring name);

#endif
