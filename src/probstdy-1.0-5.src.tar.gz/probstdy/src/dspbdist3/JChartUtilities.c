#include <stdio.h>
#include <assert.h>
#include "JChartUtilities.h"
#include "JClassLoader.h"

static void JChartUtilities_doWriteChartAsJPEG(JNIEnv* env, jobject loader, jstring name, jobject chart, int width, int height);
static void JChartUtilities_doWriteChartAsJPEG_1(JNIEnv* env, jobject loader, jobject out, jobject chart, int width, int height);
static jobject newFileOutputStream(JNIEnv* env, jstring name);
static JChartUtilities _jChartUtil = {
	.FP_writeChartAsJPEG = JChartUtilities_doWriteChartAsJPEG,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JChartUtilities_writeChartAsJPEG(JNIEnv* env, jobject loader, jstring name, jobject chart, int width, int height)
{
	assert(env != 0);
	assert(loader != 0);
	assert(name != 0);
	assert(chart != 0);
	_jChartUtil.FP_writeChartAsJPEG(env, loader, name, chart, width, height);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JChartUtilities_doWriteChartAsJPEG(JNIEnv* env, jobject loader, jstring name, jobject chart, int width, int height)
{
	jobject fos = newFileOutputStream(env, name);
	JChartUtilities_doWriteChartAsJPEG_1(env, loader, fos, chart, width, height);
}
static void JChartUtilities_doWriteChartAsJPEG_1(JNIEnv* env, jobject loader, jobject out, jobject chart, int width, int height)
{
	jvalue argValues[] = {
		[0] = { .l = out},
		[1] = { .l = chart},
		[2] = { .i = width},
		[3] = { .i = height},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,ChartUtilities));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "writeChartAsJPEG", "(Ljava/io/OutputStream;Lorg/jfree/chart/JFreeChart;II)V");
	
	JClass_CallStaticVoidMethodA(env, clz, mid, argValues);
}
static jobject newFileOutputStream(JNIEnv* env, jstring name)
{
	jvalue argValues[] = {
		[0] = { .l = name},
	};
	jclass  clz = JClass_FindClass(env, "java/io/FileOutputStream");
	return JClass_NewObjectA(env, clz, "(Ljava/lang/String;)V", argValues);
	
}
