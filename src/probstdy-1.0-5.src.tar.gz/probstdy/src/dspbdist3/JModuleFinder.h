#ifndef _JModuleFinder_H_
#define _JModuleFinder_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JModuleFinder JModuleFinder;

struct _JModuleFinder
{
	jobject (*FP_of)(JNIEnv *env, jobject path);
	jobject (*FP_findAll)(JNIEnv *env, jobject mfinder);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JModuleFinder_of(JNIEnv *env, jobject path);
jobject JModuleFinder_findAll(JNIEnv *env, jobject mfinder);
#endif
