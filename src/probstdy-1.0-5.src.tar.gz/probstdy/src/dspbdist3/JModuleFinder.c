#include <stdio.h>
#include <assert.h>
#include "JModuleFinder.h"

static jobject JModuleFinder_doOf(JNIEnv *env, jobject path);
static jobject JModuleFinder_doFindAll(JNIEnv *env, jobject mfinder);
static JModuleFinder _jModuleFinder = {
	.FP_of = JModuleFinder_doOf,
	.FP_findAll = JModuleFinder_doFindAll,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JModuleFinder_of(JNIEnv *env, jobject path)
{
	assert(env != 0);
	return _jModuleFinder.FP_of(env, path);
}
jobject JModuleFinder_findAll(JNIEnv *env, jobject mfinder)
{
	assert(env != 0);
	assert(mfinder != 0);
	return _jModuleFinder.FP_findAll(env, mfinder);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JModuleFinder_doOf(JNIEnv *env, jobject path)
{
	int size = (0 == path) ? 0 : 1;
	jobject entries = JClass_NewObjectArray(env, size, JClass_FindClass(env, "java/nio/file/Path"), NULL);
	jvalue argValues[] = {
		[0] = {.l = entries}
    };
	
	assert(entries != 0);
	if (path != 0) {
		JClass_SetObjectArrayElement(env, entries, 0, path);
	}
	jclass clz = JClass_FindClass(env, "java/lang/module/ModuleFinder");
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "of", "([Ljava/nio/file/Path;)Ljava/lang/module/ModuleFinder;");
	
	return JClass_CallStaticObjectMethodA(env, clz, mid, argValues);;
}
static jobject JModuleFinder_doFindAll(JNIEnv *env, jobject mfinder)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, mfinder), "findAll", "()Ljava/util/Set;");
	
	return JClass_CallObjectMethodA(env, mfinder, mid, NULL);
}
