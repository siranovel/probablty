#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "CDspBDist3.h"
#include "CBernoulliTrial.h"


static void usage();
void dspbdist3(CDspBDist3* pThis);
void calc(CDspBDist3* pThis);
void DspBDist3_init(CDspBDist3* pThis);
int main(int argc, char* argv[])
{
	if (3 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist3* pThis = getDspBDist3(updModPth);
	
	sscanf(argv[2], "%lf", &pThis->p);
	pThis->n = N;
	if (4 == argc) {
		sscanf(argv[3], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist3(pThis);
	CDspBDist3_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> <確率>| 回数\n", exeNm);
	printf("\n");
	printf("\t0 < 回数\tdefault:%d\n", N);
	printf("\t0.5 < 確率\n");
}
void dspbdist3(CDspBDist3* pThis)
{
	DspBDist3_init(pThis);
	calc(pThis);
	CDspBDist3_createChart(pThis);
	CDspBDist3_writeChartAsJPEG(pThis, "condorcet.jpg");
}
void calc(CDspBDist3* pThis)
{
	int x;
	CBernoulliTrial*     ber = pThis->ber;;
	
	for (x = 0; x < pThis->n; x++) {
		ber->p[x] = CDspBDist3_getP(pThis, x);
	}
}
void DspBDist3_init(CDspBDist3* pThis)
{
	CBernoulliTrial* ber = pThis->ber;
	const int sz = sizeof(double) * pThis->n;
	
	ber->p = malloc(sz);
	
}
