#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>
#include "CDspBDist2.h"
#include "CBernoulliTrial.h"
#include "CWeekLawOfLargeNums.h"
#include "CWeekLawOfLargeNum.h"
#include "JPaths.h"
#include "JModuleFinder.h"
#include "JSet.h"
#include "JIterator.h"
#include "JModuleReference.h"
#include "JModuleDescriptor.h"
#include "JModuleLayer.h"
#include "JConfiguration.h"
#include "JModuleLoaderMap.h"
#include "JResolvedModule.h"
#include "JFunction.h"
#include "JBootLoader.h"
#include "JBuiltinClassLoader.h"
#include "JClassLoader.h"

#include "JChartFactory.h"
#include "JXYSeries.h"
#include "JXIntervalSeries.h"
#include "JXYSeriesCollection.h"
#include "JXIntervalSeriesCollection.h"
#include "JChartUtilities.h"
#include "JJFreeChart.h"
#include "JCombinedDomainXYPlot.h"
#include "JPlot.h"
#include "JValueAxis.h"
#include "JNumberAxis.h"
#include "JXYBarRenderer.h"
#include "JStandardXYToolTipGenerator.h"
#include "JPlotOrientation.h"
#include "JXYPlot.h"
#include "JNumberTickUnit.h"
#include "JXYLineAndShapeRenderer.h"
#include "JDatasetRenderingOrder.h"
#include "JTextTitle.h"

static JavaVM* _vm = 0;
static JNIEnv* _env = 0;
static jobject _loader2 = 0;   // jfreechart
static jobject _chart = 0;

static char CDspBDist2_doTest(CDspBDist2* pThis, double x, double sd);
static void CDspBDist2_doCreateChart(CDspBDist2* pThis);
static jobject CDspBDist2_doCreateChart_2(CDspBDist2* pThis, jobject dataset0, jobject dataset1);
static jobject createDataSet_20(JNIEnv* env, double sd);
static jobject createDataSet_21(JNIEnv* env, CWeekLawOfLargeNums* weekOfNums);
static jobject createDataSet_22(JNIEnv* env, CWeekLawOfLargeNums* weekOfNums);
static jobject createDataSet_23(JNIEnv* env, CWeekLawOfLargeNums* weekOfNums);
static void CDspBDist2_doWriteChartAsJPEG(CDspBDist2* pThis, char* fileName);
static void init();
static void end();
static void updModPth(char* modPth);
static void loadModules(JNIEnv* env, jobject cf, jobject clf);
static CDspBDist2 _cDspBDist2 = {
	.FP_test = CDspBDist2_doTest,
	.FP_createChart = CDspBDist2_doCreateChart,
	.FP_writeChartAsJPEG = CDspBDist2_doWriteChartAsJPEG,
};
CDspBDist2* getDspBDist2(char* modPth)
{
	
	CDspBDist2_ctor(&_cDspBDist2, modPth);
	return &_cDspBDist2;
}
void CDspBDist2_ctor(CDspBDist2* pThis, char* modPth)
{
	pThis->ber = malloc(sizeof(CBernoulliTrial));
	pThis->weekOfNums = malloc(sizeof(CWeekLawOfLargeNums));
	
	init();
	updModPth(modPth);
}
void CDspBDist2_dtor(CDspBDist2* pThis)
{
	end();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
char CDspBDist2_test(CDspBDist2* pThis, double x, double sd)
{
	assert(pThis != 0);
	return pThis->FP_test(pThis, x, sd);
}
void CDspBDist2_createChart(CDspBDist2* pThis)
{
	assert(pThis != 0);
	pThis->FP_createChart(pThis);
}
void CDspBDist2_writeChartAsJPEG(CDspBDist2* pThis, char* fileName)
{
	assert(pThis != 0);
	pThis->FP_writeChartAsJPEG(pThis, fileName);
}
/**************************************/
/* �����¹���                         */
/**************************************/
static char CDspBDist2_doTest(CDspBDist2* pThis, double x, double sd)
{
	char ok = 1;
	/*
	 * 0.25 = 1/k^2
	 * 25/100 = 1/k^2
	 * 100/25 = k^2
	 * 10/5 = k
	 * 2 = k
	 *
	 * 0.05 = 1/k^2
	 * sqrt(0.05) = 1/k
	 * sqrt(5)/10 = 1/k
	 * k = 10/sqrt(5)
	 * k = 10*sqrt(5)/5
	 * k = 2*sqrt(5)
	 *
	 * 0.02 = 1/k^2
	 * sqrt(0.02) = 1/k
	 * sqrt(2)/10 = 1/k
	 * k = 10/sqrt(2)
	 * k = 10*sqrt(2)/2
	 * k = 5*sqrt(2)
	 *
	 * 0.01 = 1/k^2
	 * sqrt(0.01) = 1/k
	 * 1/10 = 1/k
	 * k = 10
	 */
	const double k = 2;
//	const double k = 2 * sqrt(5);
//	const double k = 5 * sqrt(2);
//	const double k = 10;
	const double kSD = k * sd;
	
	/*
	 * �����ӥ����դ�������
	 *  P(|Xn - ��| �� k��) �� 1 - 1/k^2
	 *  P(|Xn - ��| > k��) �� 1/k^2
	 *
	 * ��=0.4
	 */
	if (fabs(x - Mean04) > kSD) {
		ok = 0;
	}
	return ok;
}
static void CDspBDist2_doCreateChart(CDspBDist2* pThis)
{
	CWeekLawOfLargeNums* weekOfNums = pThis->weekOfNums;
	jobject title = JClass_StringNew(_env, "����μ�ˡ§");
	jobject domainAxisLabel = JClass_StringNew(_env, "����");
	jobject plot = newCombinedDomainXYPlot(_env, _loader2, newNumberAxis(_env, _loader2, domainAxisLabel));
	
	/*--- ���� ---*/
	jobject domainAxis = JPloat_getDomainAxis(_env, plot, 0);
	JValueAxis_setLowerBound(_env, domainAxis, CLASS_MIN - 0.005);
	JValueAxis_setUpperBound(_env, domainAxis, CLASS_MAX + 0.005);
	JValueAxis_setTickUnit(_env, domainAxis, newNumberTickUnit(_env, _loader2, 0.02));
	JValueAxis_setNumberFormatOverride(_env, domainAxis, JClass_StringNew(_env, "0.0#"));

	JCombinedDomainXYPlot_add(_env, plot, CDspBDist2_doCreateChart_2(pThis, createDataSet_21(_env, weekOfNums), createDataSet_20(_env, SD05)), 1);
	JCombinedDomainXYPlot_add(_env, plot, CDspBDist2_doCreateChart_2(pThis, createDataSet_22(_env, weekOfNums), createDataSet_20(_env, SD03)), 1);
	JCombinedDomainXYPlot_add(_env, plot, CDspBDist2_doCreateChart_2(pThis, createDataSet_23(_env, weekOfNums), createDataSet_20(_env, SD01)), 1);
	
	_chart = newJFreeChart(_env, _loader2, title, plot);
	JJFreeChart_addSubtitle(_env, _chart, newTextTitle(_env, _loader2, JClass_StringNew(_env, "(ʿ��:0.4 ������:95%)")  ));
}
/*
 * ����μ�ˡ§�Υ��ߥ�졼�����
 */
//  Plot
static jobject CDspBDist2_doCreateChart_2(CDspBDist2* pThis, jobject dataset0, jobject dataset1)
{
	jobject valueAxisLabel0 = JClass_StringNew(_env, "�ٿ�");
	jobject valueAxisLabel1 = JClass_StringNew(_env, "N");
	jobject valueAxis0 = newNumberAxis(_env, _loader2, valueAxisLabel0);
	jobject valueAxis1 = newNumberAxis(_env, _loader2, valueAxisLabel1);
	
	jobject tt = newStandardXYToolTipGenerator(_env, _loader2);
	// XYBarRenderer
	jobject renderer0 = newXYBarRenderer(_env, _loader2);
	
	// XYLineAndShapeRenderer
	jobject renderer1 = newXYLineAndShapeRenderer(_env, _loader2, JNI_TRUE, JNI_FALSE);
	
	JXYBarRenderer_setBaseToolTipGenerator(_env, renderer0, tt);
	JXYBarRenderer_setBaseToolTipGenerator(_env, renderer1, tt);
	
	// XYPlot
	jobject plot = newXYPlot(_env, _loader2);
	JXYPlot_setOrientation(_env, plot, JPlotOrientation_VERTICAL(_env, _loader2));
	JPlot_mapDatasetToRangeAxis(_env, plot, 0, 0);
	JPlot_mapDatasetToRangeAxis(_env, plot, 1, 1);
	JPlot_setDatasetRenderingOrder(_env, plot, JDatasetRenderingOrder_FORWARD(_env, _loader2));
	
	JXYPlot_setRangeAxis(_env, plot, 0, valueAxis0);
	JXYPlot_setDataset(_env, plot, 0, dataset0);
	JXYPlot_setRenderer(_env, plot, 0, renderer0);
	
	JXYPlot_setRangeAxis(_env, plot, 1, valueAxis1);
	JXYPlot_setDataset(_env, plot, 1, dataset1);
	JXYPlot_setRenderer(_env, plot, 1, renderer1);
	
	/*--- �ļ� ---*/
	jobject rangeAumAxis0 = JPloat_getRangeAxis(_env, plot, 0);   // NumberAxis
	JValueAxis_setLowerBound(_env, rangeAumAxis0, 0.0);
	JValueAxis_setUpperBound(_env, rangeAumAxis0, pThis->n * 0.5);
	JValueAxis_setTickUnit(_env, rangeAumAxis0, newNumberTickUnit(_env, _loader2, 100));
	
	jobject rangeAumAxis1 = JPloat_getRangeAxis(_env, plot, 1);   // NumberAxis
	JValueAxis_setLowerBound(_env, rangeAumAxis1, 0.0);
	
	return plot;
}


//  DataSet
static jobject createDataSet_20(JNIEnv* env, double sd)
{
	char yAxis[32];
	
	sprintf(yAxis, "N(%.1f, %.2lf^2)", Mean04, sd);
	jobject p04 = newXYSeries(env, _loader2, JClass_StringNew(_env, yAxis));
	double x = 0;
	
	for (x = 0; x + CLASS_MIN <= CLASS_MAX; x += 0.001) {
		double y = 1 / (sqrt(2 * M_PI) * sd) * exp(-1 * (x + CLASS_MIN - Mean04) * (x + CLASS_MIN - Mean04) / (2 * sd * sd));
		
		JXYSeries_add(env, p04, x + CLASS_MIN, y);
	}
	jobject series = newXYSeriesCollection(env, _loader2);
	
	JXYSeriesCollection_addSeries(env, series, p04);
	return series;
}
static jobject createDataSet_21(JNIEnv* env, CWeekLawOfLargeNums* weekOfNums)
{
	int i;
	jobject p04 = newXIntervalSeries(env, _loader2, JClass_StringNew(_env, "SD:0.05"));
	
	for (i = 0; i < weekOfNums->n; i++) {
		CWeekLawOfLargeNum* weekOfNum = &weekOfNums->weekOfNum[i];
		
		JXIntervalSeries_add(env, p04, weekOfNum->rank, weekOfNum->rank - 0.005, weekOfNum->rank + 0.005, weekOfNum->cnt005);
	}
	
	jobject series = newXIntervalSeriesCollection(env, _loader2);
	JXIntervalSeriesCollection_addSeries(env, series, p04);
	return series;
}
static jobject createDataSet_22(JNIEnv* env, CWeekLawOfLargeNums* weekOfNums)
{
	int i;
	jobject p04 = newXIntervalSeries(env, _loader2, JClass_StringNew(_env, "SD:0.03"));
	
	for (i = 0; i < weekOfNums->n; i++) {
		CWeekLawOfLargeNum* weekOfNum = &weekOfNums->weekOfNum[i];
		
		JXIntervalSeries_add(env, p04, weekOfNum->rank, weekOfNum->rank - 0.005, weekOfNum->rank + 0.005, weekOfNum->cnt003);
	}
	
	jobject series = newXIntervalSeriesCollection(env, _loader2);
	JXIntervalSeriesCollection_addSeries(env, series, p04);
	return series;
}
static jobject createDataSet_23(JNIEnv* env, CWeekLawOfLargeNums* weekOfNums)
{
	int i;
	jobject p04 = newXIntervalSeries(env, _loader2, JClass_StringNew(_env, "SD:0.01"));
	
	for (i = 0; i < weekOfNums->n; i++) {
		CWeekLawOfLargeNum* weekOfNum = &weekOfNums->weekOfNum[i];
		
		JXIntervalSeries_add(env, p04, weekOfNum->rank, weekOfNum->rank - 0.005, weekOfNum->rank + 0.005, weekOfNum->cnt001);
	}
	
	jobject series = newXIntervalSeriesCollection(env, _loader2);
	JXIntervalSeriesCollection_addSeries(env, series, p04);
	return series;
}

static void CDspBDist2_doWriteChartAsJPEG(CDspBDist2* pThis, char* fileName)
{
	JChartUtilities_writeChartAsJPEG(_env, _loader2, JClass_StringNew(_env, fileName), _chart, 600, 900);
}
static JavaVMOption jvmOpts[] = {
	{.optionString = "-XX:+UnlockExperimentalVMOptions", .extraInfo=NULL}
	,{.optionString = "-XX:+EnableJVMCI", .extraInfo=NULL}
	
};
static JavaVMInitArgs vm_args = {
	.version = JNI_VERSION_1_8,
	.nOptions = NSIZE(jvmOpts),
	.options = jvmOpts
};
static void init()
{
	JNI_CreateJavaVM(&_vm, (void **)&_env, (void *)&vm_args);
	
}
static void end()
{
	assert(_vm != NULL);
	(*_vm)->DestroyJavaVM(_vm);
}
static void updModPth(char* modPth)
{
	jobject jmodPath = JPaths_get(_env, JClass_StringNew(_env, modPth));
	jobject mfinder = JModuleFinder_of(_env, jmodPath);
	jobject refs = JModuleFinder_findAll(_env, mfinder);
	jobject iteObj = JSet_iterator(_env, refs);
	
	jobject roots = newSet(_env);
	while(JNI_TRUE == JIterator_hasNext(_env, iteObj)) {
		jobject mref = JIterator_next(_env, iteObj);          // ModuleReference
		jobject mdesc = JModuleReference_descriptor(_env, mref); // ModuleDescriptor
		jstring jdescName = JModuleDescriptor_name(_env, mdesc);
		
		JSet_add(_env, roots, jdescName);
	}
	/*
     *    ModuleFinder finder = ModuleFinder.of(dir1, dir2, dir3);
	 *    ModuleLayer bootLayer = ModuleLayer.boot();
     *    Configuration parent = bootLayer.configuration();
     *    Configuration cf = parent.resolve(finder, ModuleFinder.of(new Path[0]), Set.of("myapp"));
	 *    Function<String, ClassLoader> clf = ModuleLoaderMap.mappingFunction(cf);
     *    ModuleBootstrap.loadModules(cf, clf);
     *        for (ResolvedModule resolvedModule : cf.modules()) {
     *            ModuleReference mref = resolvedModule.reference();
     *            String name = resolvedModule.name();
     *            ClassLoader loader = clf.apply(name);
     *            if (loader == null) {
     *               // skip java.base as it is already loaded
     *               if (!name.equals(JAVA_BASE)) {
     *                   BootLoader.loadModule(mref);
     *               }
     *            } else if (loader instanceof BuiltinClassLoader) {
     *                ((BuiltinClassLoader) loader).loadModule(mref);
     *            }
     *        }
	 */
	jobject bootLayer = JModuleLayer_boot(_env);
	jobject parent = JModuleLayer_configuration(_env, bootLayer);
	jobject cf = JConfiguration_resolveAndBind(_env, parent, mfinder, JModuleFinder_of(_env, 0), roots);
	jobject clf = JModuleLoaderMap_mappingFunction(_env, cf);
	
	loadModules(_env, cf, clf);
	jobject emptyM = JModuleLayer_defineModules(_env, bootLayer, cf, clf);
	// ���ܸ줬ʸ���������ʤ��ơ���
	_loader2 = JModuleLayer_findLoader(_env, emptyM, JClass_StringNew(_env,"jfreechart"));  // ClassLoader jdbc = emptyM.findLoader("jfreechart")
	JChartFactory_setChartTheme(_env, _loader2);
}
static void loadModules(JNIEnv* env, jobject cf, jobject clf)
{
	jobject reslvedMs = JConfiguration_modules(env, cf);
	jobject iteObj = JSet_iterator(env, reslvedMs);

	while(JNI_TRUE == JIterator_hasNext(env, iteObj)) {
		jobject resolvedModule = JIterator_next(env, iteObj);          // ResolvedModule
		jobject mref = JResolvedModule_reference(env, resolvedModule); // ModuleReference
		jstring name = JResolvedModule_name(env, resolvedModule);
		jobject loader = JFunction_apply(env, clf, name);

		if (0 == loader) {
			const char* _name = JClass_GetStringUTFChars(env, name);
			
			if (0 != strcmp("java.base", _name)) {
				JBootLoader_loadModule(env, mref);
			}
		} else if (JNI_TRUE == JClass_IsInstanceOf(env, loader, JClass_FindClass(env, "jdk/internal/loader/BuiltinClassLoader"))) {
			JBuiltinClassLoader_loadModule(env, loader, mref);
		}
	}
}
