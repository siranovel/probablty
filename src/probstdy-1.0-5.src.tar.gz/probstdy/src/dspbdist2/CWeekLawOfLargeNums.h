#ifndef _CWeekLawOfLargeNums_H_
#define _CWeekLawOfLargeNums_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CWeekLawOfLargeNums CWeekLawOfLargeNums;
typedef struct _CWeekLawOfLargeNum CWeekLawOfLargeNum;

struct _CWeekLawOfLargeNums
{
	int n;
	CWeekLawOfLargeNum* weekOfNum;
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
#endif
