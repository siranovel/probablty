#ifndef _CWeekLawOfLargeNum_H_
#define _CWeekLawOfLargeNum_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CWeekLawOfLargeNum CWeekLawOfLargeNum;

struct _CWeekLawOfLargeNum
{
	double rank;
	int    cnt001;
	int    cnt003;
	int    cnt005;
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
#endif
