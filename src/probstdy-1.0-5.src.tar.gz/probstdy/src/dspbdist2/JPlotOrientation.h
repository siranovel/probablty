#ifndef _JPlotOrientation_H_
#define _JPlotOrientation_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JPlotOrientation JPlotOrientation;

struct _JPlotOrientation
{
	jobject (*FP_HORIZONTAL)(JNIEnv* env, jobject loader);
	jobject (*FP_VERTICAL)(JNIEnv* env, jobject loader);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define PlotOrientation "org.jfree.chart.plot.PlotOrientation"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JPlotOrientation_HORIZONTAL(JNIEnv* env, jobject loader);
jobject JPlotOrientation_VERTICAL(JNIEnv* env, jobject loader);
#endif
