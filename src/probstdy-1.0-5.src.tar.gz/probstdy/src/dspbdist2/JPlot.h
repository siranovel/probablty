#ifndef _JPlot_H_
#define _JPlot_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JPlot JPlot;

struct _JPlot
{
	jobject (*FP_getRangeAxis)(JNIEnv* env, jobject plot, int index);
	jobject (*FP_getDomainAxis)(JNIEnv* env, jobject plot, int index);
	void    (*FP_mapDatasetToRangeAxis)(JNIEnv* env, jobject plot, int index, int axisIndex);
	void    (*FP_setDatasetRenderingOrder)(JNIEnv* env, jobject plot, jobject order);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JPloat_getRangeAxis(JNIEnv* env, jobject plot, int index);
jobject JPloat_getDomainAxis(JNIEnv* env, jobject plot, int index);
void JPlot_mapDatasetToRangeAxis(JNIEnv* env, jobject plot, int index, int axisIndex);
void JPlot_setDatasetRenderingOrder(JNIEnv* env, jobject plot, jobject order);
#endif
