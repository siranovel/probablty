#include <stdio.h>
#include <assert.h>
#include "JXIntervalSeriesCollection.h"
#include "JClassLoader.h"

static jobject doNewXIntervalSeriesCollection(JNIEnv* env, jobject loader);
static void JXIntervalSeriesCollection_doAddSeries(JNIEnv* env, jobject seriesColl, jobject series);
static JXIntervalSeriesCollection _jXIntervalSeriesCollection = {
	.FP_addSeries = JXIntervalSeriesCollection_doAddSeries,
};
jobject newXIntervalSeriesCollection(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXIntervalSeriesCollection(env, loader);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXIntervalSeriesCollection_addSeries(JNIEnv* env, jobject seriesColl, jobject series)
{
	assert(env != 0);
	assert(seriesColl != 0);
	assert(series != 0);
	
	_jXIntervalSeriesCollection.FP_addSeries(env, seriesColl, series);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXIntervalSeriesCollection(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XIntervalSeriesCollection));
	
	return JClass_NewObjectA(env, clz, "()V", 0);
}
static void JXIntervalSeriesCollection_doAddSeries(JNIEnv* env, jobject seriesColl, jobject series)
{
	jvalue argValues[] = {
		[0] = { .l = series},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, seriesColl), "addSeries", "(Lorg/jfree/data/xy/XIntervalSeries;)V");
	
	JClass_CallVoidMethodA(env, seriesColl, mid, argValues);
}
