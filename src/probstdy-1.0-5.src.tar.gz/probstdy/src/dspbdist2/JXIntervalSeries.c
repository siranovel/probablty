#include <stdio.h>
#include <assert.h>
#include "JXIntervalSeries.h"
#include "JClassLoader.h"

static jobject doNewXIntervalSeries(JNIEnv* env, jobject loader, jstring key);
static void JXYSeries_doAdd(JNIEnv* env, jobject series, double x, double xLow, double xHigh, double y);
static JXIntervalSeries _jXIntervalSeries = {
	.FP_add = JXYSeries_doAdd,
};
jobject newXIntervalSeries(JNIEnv* env, jobject loader, jstring key)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXIntervalSeries(env, loader, key);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXIntervalSeries_add(JNIEnv* env, jobject series, double x, double xLow, double xHigh, double y)
{
	assert(env != 0);
	assert(series != 0);
	_jXIntervalSeries.FP_add(env, series, x, xLow, xHigh, y);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXIntervalSeries(JNIEnv* env, jobject loader, jstring key)
{
	jvalue argValues[] = {
		[0] = { .l = key},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XIntervalSeries));
	
	return JClass_NewObjectA(env, clz, "(Ljava/lang/Comparable;)V", argValues);
}
static void JXYSeries_doAdd(JNIEnv* env, jobject series, double x, double xLow, double xHigh, double y)
{
	jvalue argValues[] = {
		[0] = { .d = x},
		[1] = { .d = xLow},
		[2] = { .d = xHigh},
		[3] = { .d = y},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, series), "add", "(DDDD)V");
	
	JClass_CallVoidMethodA(env, series, mid, argValues);
}
