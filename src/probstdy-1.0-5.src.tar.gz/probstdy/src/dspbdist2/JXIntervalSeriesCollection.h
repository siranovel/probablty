#ifndef _JXIntervalSeriesCollection_H_
#define _JXIntervalSeriesCollection_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JXIntervalSeriesCollection JXIntervalSeriesCollection;

struct _JXIntervalSeriesCollection
{
	void (*FP_addSeries)(JNIEnv* env, jobject seriesColl, jobject series);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define XIntervalSeriesCollection     "org.jfree.data.xy.XIntervalSeriesCollection"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXIntervalSeriesCollection(JNIEnv* env, jobject loader);
void JXIntervalSeriesCollection_addSeries(JNIEnv* env, jobject seriesColl, jobject series);
#endif
