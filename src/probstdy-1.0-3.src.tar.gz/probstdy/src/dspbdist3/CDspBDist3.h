#ifndef _CDspBDist3_H_
#define _CDspBDist3_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist3 CDspBDist3;
typedef struct _CBernoulliTrial CBernoulliTrial;

struct _CDspBDist3
{
	int n;
	double p;
	CBernoulliTrial*     ber;
	double (*FP_getP)(CDspBDist3* pThis, int x);
	void (*FP_createChart)(CDspBDist3* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist3* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 1200
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist3* getDspBDist3(char* modPth);
void CDspBDist3_ctor(CDspBDist3* pThis, char* modPth);
void CDspBDist3_dtor(CDspBDist3* pThis);
double CDspBDist3_getP(CDspBDist3* pThis, int x);
void CDspBDist3_createChart(CDspBDist3* pThis);
void CDspBDist3_writeChartAsJPEG(CDspBDist3* pThis, char* fileName);
#endif
