#ifndef _JTextTitle_H_
#define _JTextTitle_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
/**************************************/
/* define�錾                         */
/**************************************/
#define TextTitle     "org.jfree.chart.title.TextTitle"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newTextTitle(JNIEnv* env, jobject loader, jstring text);
#endif
