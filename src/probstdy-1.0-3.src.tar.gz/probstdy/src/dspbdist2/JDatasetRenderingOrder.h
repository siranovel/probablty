#ifndef _JDatasetRenderingOrder_H_
#define _JDatasetRenderingOrder_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JDatasetRenderingOrder JDatasetRenderingOrder;

struct _JDatasetRenderingOrder
{
	jobject (*FP_FORWARD)(JNIEnv* env, jobject loader);
	jobject (*FP_REVERSE)(JNIEnv* env, jobject loader);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define DatasetRenderingOrder "org.jfree.chart.plot.DatasetRenderingOrder"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JDatasetRenderingOrder_FORWARD(JNIEnv* env, jobject loader);
jobject JDatasetRenderingOrder_REVERSE(JNIEnv* env, jobject loader);
#endif
