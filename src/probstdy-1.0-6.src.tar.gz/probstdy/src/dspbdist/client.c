#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "CDspBDist.h"
#include "CBernoulliTrial.h"


static void usage();
void dspbdist(CDspBDist* pThis);
void calc(CDspBDist* pThis);
int getRandom(int min, int max);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist* pThis = getDspBDist(updModPth);
	
	pThis->n = N;
	if (3 == argc) {
		sscanf(argv[2], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist(pThis);
	CDspBDist_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | 回数\n", exeNm);
	printf("\n");
	printf("\t0 < 回数\tdefault:%d\n", N);
}
void dspbdist(CDspBDist* pThis)
{
	calc(pThis);
	CDspBDist_createChart(pThis);
	CDspBDist_writeChartAsJPEG(pThis, "bernoulli.jpg");
}
void calc(CDspBDist* pThis)
{
	CBernoulliTrial*     ber = pThis->ber;
	int i;
	const int sz = sizeof(double) * pThis->n;
	int cnt01 = 0;
	int cnt04 = 0;
	int cnt09 = 0;
	
	ber->p01 = malloc(sz);
	ber->p04 = malloc(sz);
	ber->p09 = malloc(sz);
	memset(ber->p01, 0, sz);
	memset(ber->p04, 0, sz);
	memset(ber->p09, 0, sz);
	srand(time(0));
	for (i = 0; i < pThis->n; i++) {
		int rnd = getRandom(0, 99);
		
		if (10 > rnd) {
			cnt01++;
		}
		if(40 > rnd) {
			cnt04++;
		}
		if(90 > rnd) {
			cnt09++;
		}
		
		ber->p01[i] = ((double)cnt01) / ((double)(i + 1));
		ber->p04[i] = ((double)cnt04) / ((double)(i + 1));
		ber->p09[i] = ((double)cnt09) / ((double)(i + 1));
	}
	
}
int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
