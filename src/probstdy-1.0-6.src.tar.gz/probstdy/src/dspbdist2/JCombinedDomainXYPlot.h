#ifndef _JCombinedDomainXYPlot_H_
#define _JCombinedDomainXYPlot_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JCombinedDomainXYPlot JCombinedDomainXYPlot;

struct _JCombinedDomainXYPlot
{
	void (*FP_add)(JNIEnv* env, jobject combDomPlotObj, jobject subplot, int weight);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define CombinedDomainXYPlot  "org.jfree.chart.plot.CombinedDomainXYPlot"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newCombinedDomainXYPlot(JNIEnv* env, jobject loader, jobject domainAxis);
void JCombinedDomainXYPlot_add(JNIEnv* env, jobject combDomPlotObj, jobject subplot, int weight);
#endif
