#ifndef _JPlot_H_
#define _JPlot_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JPlot JPlot;

struct _JPlot
{
	jobject (*FP_getRangeAxis)(JNIEnv* env, jobject plot);
	jobject (*FP_getDomainAxis)(JNIEnv* env, jobject plot);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JPloat_getRangeAxis(JNIEnv* env, jobject plot);
jobject JPloat_getDomainAxis(JNIEnv* env, jobject plot);
#endif
