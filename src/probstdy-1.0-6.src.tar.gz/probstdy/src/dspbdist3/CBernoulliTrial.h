#ifndef _CBernoulliTrial_H_
#define _CBernoulliTrial_H_

/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CBernoulliTrial CBernoulliTrial;

struct _CBernoulliTrial
{
	double *p;
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
#endif
