#ifndef _JBinomialDistribution_H_
#define _JBinomialDistribution_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JBinomialDistribution JBinomialDistribution;

struct _JBinomialDistribution
{
	jdouble (*FP_cumulativeProbability)(JNIEnv* env, jobject bidistObj, int x);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define BI_DIST "org.apache.commons.math3.distribution.BinomialDistribution"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p);
jdouble JBinomialDistribution_cumulativeProbability(JNIEnv* env, jobject bidistObj, int x);
#endif
