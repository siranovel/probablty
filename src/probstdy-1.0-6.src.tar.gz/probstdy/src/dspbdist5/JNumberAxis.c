#include <stdio.h>
#include <assert.h>
#include "JNumberAxis.h"
#include "JClassLoader.h"

static jobject doNewNumberAxis(JNIEnv* env, jobject loader, char* label);
jobject newNumberAxis(JNIEnv* env, jobject loader, char* label)
{
	return doNewNumberAxis(env, loader, label);
}

/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewNumberAxis(JNIEnv* env, jobject loader, char* label)
{
	jvalue argValues[] = {
			[0] = { .l = JClass_StringNew(env, label)},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,NumberAxis));
	return JClass_NewObjectA(env, clz, "(Ljava/lang/String;)V", argValues);
}
