#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "CDspBDist6.h"


static void usage();
void dspbdist6(CDspBDist6* pThis);
void calc(CDspBDist6* pThis);
int getRandom(int min, int max);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist6* pThis = getDspBDist6(updModPth);
	
	pThis->n = N;
	if (3 == argc) {
		sscanf(argv[2], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist6(pThis);
	CDspBDist6_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | ���", exeNm);
	printf("\n");
	printf("\t0 < ���\tdefault:%d\n", N);
}
void dspbdist6(CDspBDist6* pThis)
{
	calc(pThis);
	CDspBDist6_createChart(pThis);
	CDspBDist6_writeChartAsJPEG(pThis, "brown.jpg");
}
void calc(CDspBDist6* pThis)
{
	int i;
	int j;
	const int sz = sizeof(double) * pThis->n;
	const double C = 1.0 / pThis->n;
	const double CW = sqrt(C);
	
	srand(time(0));
	for (i = 0; i < NTIME(pThis->brown); i++) {
		CBrown*     brown = &pThis->brown[i];

		brown->p05 = malloc(sz);
		memset(brown->p05, 0, sz);
		double* p05 = brown->p05;
		for(j = 0; j < pThis->n; j++) {
			int rnd = getRandom(0, 99);
			
			p05[j] = -1 * CW;
			if(50 > rnd) {
				p05[j] = 1 * CW;
			}
		}
	}
}
int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
