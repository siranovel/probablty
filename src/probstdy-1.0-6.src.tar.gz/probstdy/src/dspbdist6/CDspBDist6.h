#ifndef _CDspBDist6_H_
#define _CDspBDist6_H_

#include "CBrown.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist6 CDspBDist6;

struct _CDspBDist6
{
	int n;
	CBrown brown[5];
	void (*FP_createChart)(CDspBDist6* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist6* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 1200
#define NTIME(a) NSIZE(a)
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist6* getDspBDist6(char* modPth);
void CDspBDist6_ctor(CDspBDist6* pThis, char* modPth);
void CDspBDist6_dtor(CDspBDist6* pThis);
void CDspBDist6_createChart(CDspBDist6* pThis);
void CDspBDist6_writeChartAsJPEG(CDspBDist6* pThis, char* fileName);

#endif
