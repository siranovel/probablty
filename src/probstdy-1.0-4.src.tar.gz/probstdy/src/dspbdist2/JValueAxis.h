#ifndef _JValueAxis_H_
#define _JValueAxis_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JValueAxis JValueAxis;

struct _JValueAxis
{
	void (*FP_setLowerBound)(JNIEnv* env, jobject axis, double min);
	void (*FP_setUpperBound)(JNIEnv* env, jobject axis, double max);
	void (*FP_setLowerMargin)(JNIEnv* env, jobject axis, double margin);
	void (*FP_setUpperMargin)(JNIEnv* env, jobject axis, double margin);
	void (*FP_setTickUnit)(JNIEnv* env, jobject axis, jobject unit);
	void (*FP_setNumberFormatOverride)(JNIEnv* env, jobject axis, jstring pattern);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JValueAxis_setLowerBound(JNIEnv* env, jobject axis, double min);
void JValueAxis_setUpperBound(JNIEnv* env, jobject axis, double max);
void JValueAxis_setLowerMargin(JNIEnv* env, jobject axis, double margin);
void JValueAxis_setUpperMargin(JNIEnv* env, jobject axis, double margin);
void JValueAxis_setTickUnit(JNIEnv* env, jobject axis, jobject unit);
void JValueAxis_setNumberFormatOverride(JNIEnv* env, jobject axis, jstring pattern);
#endif
