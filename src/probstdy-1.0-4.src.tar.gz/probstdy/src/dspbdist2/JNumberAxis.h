#ifndef _JNumberAxis_H_
#define _JNumberAxis_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
/**************************************/
/* define�錾                         */
/**************************************/
#define NumberAxis "org.jfree.chart.axis.NumberAxis"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newNumberAxis(JNIEnv* env, jobject loader, jstring label);

#endif
