#include <stdio.h>
#include <assert.h>
#include "JChartFactory.h"
#include "JClassLoader.h"

static void JChartFactory_doSetChartTheme(JNIEnv* env, jobject loader);
static void JChartFactory_doSetChartTheme_1(JNIEnv* env, jobject loader, jobject theme);
static jobject JStandardChartTheme_createLegacyTheme(JNIEnv* env, jobject loader);
static jobject JChartFactory_doCreateXYLineChart(JNIEnv* env, jobject loader, jstring title, jstring xAxisLabel, jstring yAxisLabel, jobject dataset);
static JChartFactory _JChartFactory = {
	.FP_setChartTheme     = JChartFactory_doSetChartTheme,
	.FP_createXYLineChart = JChartFactory_doCreateXYLineChart,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JChartFactory_setChartTheme(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	_JChartFactory.FP_setChartTheme(env, loader);
}
jobject JChartFactory_createXYLineChart(JNIEnv* env, jobject loader, jstring title, jstring xAxisLabel, jstring yAxisLabel, jobject dataset)
{
	assert(env != 0);
	assert(loader != 0);
	return _JChartFactory.FP_createXYLineChart(env, loader, title, xAxisLabel, yAxisLabel, dataset);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JChartFactory_doSetChartTheme(JNIEnv* env, jobject loader)
{
	JChartFactory_doSetChartTheme_1(env, loader, JStandardChartTheme_createLegacyTheme(env, loader));
}
static void JChartFactory_doSetChartTheme_1(JNIEnv* env, jobject loader, jobject theme)
{
	assert(env != 0);
	assert(theme != 0);
	
	jvalue argValues[] = {
		[0] = { .l = theme},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,ChartFactory));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "setChartTheme", "(Lorg/jfree/chart/ChartTheme;)V");
	
	JClass_CallStaticVoidMethodA(env, clz, mid, argValues);
}
static jobject JChartFactory_doCreateXYLineChart(JNIEnv* env, jobject loader, jstring title, jstring xAxisLabel, jstring yAxisLabel, jobject dataset)
{
	jvalue argValues[] = {
		[0] = { .l = title},
		[1] = { .l = xAxisLabel},
		[2] = { .l = yAxisLabel},
		[3] = { .l = dataset},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,ChartFactory));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "createXYLineChart", 
		"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/jfree/data/xy/XYDataset;)Lorg/jfree/chart/JFreeChart;");
	
	return JClass_CallStaticObjectMethodA(env, clz, mid, argValues);
}
static jobject JStandardChartTheme_createLegacyTheme(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,StandardChartTheme));
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "createLegacyTheme", "()Lorg/jfree/chart/ChartTheme;");
	
	return JClass_CallStaticObjectMethodA(env, clz, mid, 0);
}
