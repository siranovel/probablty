#include <stdio.h>
#include <assert.h>
#include "JClassLoader.h"

static jclass JClassLoader_doLoadClass(JNIEnv* env, jobject loader, jstring name);
static JClassLoader _jClsLoader = {
	.FP_loadClass = JClassLoader_doLoadClass,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jclass JClassLoader_loadClass(JNIEnv* env, jobject loader, jstring name)
{
	assert(env != 0);
	return _jClsLoader.FP_loadClass(env, loader, name);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jclass JClassLoader_doLoadClass(JNIEnv* env, jobject loader, jstring name)
{
	jvalue argValues[] = {
		[0] = { .l = name},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, loader), "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
	return JClass_CallObjectMethodA(env, loader, mid, argValues);
}
