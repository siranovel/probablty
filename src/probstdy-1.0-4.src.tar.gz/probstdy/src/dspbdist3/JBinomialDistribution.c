#include <stdio.h>
#include <assert.h>
#include "JBinomialDistribution.h"
#include "JClassLoader.h"

static jobject doNewBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p);
static jdouble JBinomialDistribution_doCumulativeProbability(JNIEnv* env, jobject bidistObj, int x);
static JBinomialDistribution _jBiDist = {
	.FP_cumulativeProbability = JBinomialDistribution_doCumulativeProbability,
};
jobject newBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p)
{
	assert(env != 0);
	assert(loader != 0);
	
	return doNewBinomialDistribution(env, loader, trials, p);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jdouble JBinomialDistribution_cumulativeProbability(JNIEnv* env, jobject bidistObj, int x)
{
	assert(0 != env);
	assert(0 != bidistObj);
	return _jBiDist.FP_cumulativeProbability(env, bidistObj, x);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewBinomialDistribution(JNIEnv* env, jobject loader, jint trials, jdouble p)
{
	jvalue argValues[] = {
		[0] = { .i = trials},
		[1] = { .d = p},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,BI_DIST));
	
	return JClass_NewObjectA(env, clz, "(ID)V", argValues);
}
static jdouble JBinomialDistribution_doCumulativeProbability(JNIEnv* env, jobject bidistObj, int x)
{
	jvalue argValues[] = {
		[0] = { .i = x},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, bidistObj), "cumulativeProbability", "(I)D");
	return JClass_CallDoubleMethodA(env, bidistObj, mid, argValues);
	
}
