#include <stdio.h>
#include <assert.h>
#include "JPaths.h"

static jobject JPaths_doGet(JNIEnv *env, char* updModPath);
static JPaths _jPaths = {
	.FP_get = JPaths_doGet,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JPaths_get(JNIEnv *env, char* updModPath)
{
	assert(env != 0);
	return _jPaths.FP_get(env, updModPath);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JPaths_doGet(JNIEnv *env, char* updModPath)
{
	jvalue argValues[] = {
		[0] = {.l = JClass_StringNew(env, updModPath)},
		[1] = {.l = JClass_NewObjectArray(env, 0, JClass_FindClass(env, "java/lang/String"), NULL)}
    };
	jclass clz = JClass_FindClass(env, "java/nio/file/Paths");
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "get", "(Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path;");
	
	return JClass_CallStaticObjectMethodA(env, clz, mid, argValues);;
}
