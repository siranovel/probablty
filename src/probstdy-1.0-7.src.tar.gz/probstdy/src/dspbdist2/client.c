#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "CDspBDist2.h"
#include "CBernoulliTrial.h"
#include "CWeekLawOfLargeNums.h"
#include "CWeekLawOfLargeNum.h"

static void usage();
void dspbdist2(CDspBDist2* pThis);
void calc(CDspBDist2* pThis);
int getRandom(int min, int max);
void DspBDist2_init(CDspBDist2* pThis);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist2* pThis = getDspBDist2(updModPth);
	
	pThis->n = N;
	dspbdist2(pThis);
	CDspBDist2_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | 回数\n", exeNm);
	printf("\n");
	printf("\t0 < 回数\tdefault:%d\n", N);
}
void dspbdist2(CDspBDist2* pThis)
{
	DspBDist2_init(pThis);
	calc(pThis);
	CDspBDist2_createChart(pThis);
	CDspBDist2_writeChartAsJPEG(pThis, "weekLawOfLargeNums.jpg");
}
void calc(CDspBDist2* pThis)
{
	int i;
	int cnt01 = 0;
	int cnt04 = 0;
	int cnt09 = 0;
	double p04 = 0;
	CBernoulliTrial* ber = pThis->ber;
	CWeekLawOfLargeNums* weekOfNums = pThis->weekOfNums;
	CWeekLawOfLargeNum* weekOfNum = weekOfNums->weekOfNum;
	
	srand(1);
	for (i = 0; i < pThis->n; i++) {
		int rnd = getRandom(0, TIME - 1);
		
		if (TIME * 0.1 > rnd) {
			cnt01++;
		}
		if(TIME * 0.4 > rnd) {
			cnt04++;
		}
		if(TIME * 0.9 > rnd) {
			cnt09++;
		}
		ber->p01[i] = ((double)cnt01) / ((double)(i + 1.0));
		ber->p04[i] = ((double)cnt04) / ((double)(i + 1.0));
		ber->p09[i] = ((double)cnt09) / ((double)(i + 1.0));
		p04 =cnt04 / (i + 1.0);
		
		if (CDspBDist2_test(pThis, p04, SD01)) {
			int j = 0;
			
			for (j = 0; j < weekOfNums->n; j++) {
				if ((weekOfNum[j].rank - 0.005 <= p04) && (p04 < (weekOfNum[j].rank + 0.005))) {
					weekOfNum[j].cnt001++;
				}
			}
		}
		if (CDspBDist2_test(pThis, p04, SD03)) {
			int j = 0;
			
			for (j = 0; j < weekOfNums->n; j++) {
				if ((weekOfNum[j].rank - 0.005 <= p04) && (p04 < (weekOfNum[j].rank + 0.005))) {
					weekOfNum[j].cnt003++;
				}
			}
		}
		if (CDspBDist2_test(pThis, p04, SD05)) {
			int j = 0;
			
			for (j = 0; j < weekOfNums->n; j++) {
				if ((weekOfNum[j].rank - 0.005 <= p04) && (p04 < (weekOfNum[j].rank + 0.005))) {
					weekOfNum[j].cnt005++;
				}
			}
		}
	}
}
int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
void DspBDist2_init(CDspBDist2* pThis)
{
	int i;
	const int sz = sizeof(double) * pThis->n;
	CBernoulliTrial* ber = pThis->ber;
	CWeekLawOfLargeNums* weekOfNums = pThis->weekOfNums;
	
	ber->p01 = malloc(sz);
	ber->p04 = malloc(sz);
	ber->p09 = malloc(sz);
	memset(ber->p01, 0, sz);
	memset(ber->p04, 0, sz);
	memset(ber->p09, 0, sz);
	
	weekOfNums->n = (CLASS_MAX - CLASS_MIN) / 0.01 + 1;
	CWeekLawOfLargeNum* weekOfNum = weekOfNums->weekOfNum = malloc(sizeof(CWeekLawOfLargeNum) * weekOfNums->n);
	for (i = 0; i < weekOfNums->n; i++) {
		weekOfNum[i].rank = CLASS_MIN + 0.01 * i;
		weekOfNum[i].cnt005 = 0;
		weekOfNum[i].cnt003 = 0;
		weekOfNum[i].cnt001 = 0;
	}
}
