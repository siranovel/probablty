#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "CDspBDist5.h"
#include "JPaths.h"
#include "JModuleFinder.h"
#include "JSet.h"
#include "JIterator.h"
#include "JModuleReference.h"
#include "JModuleDescriptor.h"
#include "JModuleLayer.h"
#include "JConfiguration.h"
#include "JModuleLoaderMap.h"
#include "JResolvedModule.h"
#include "JFunction.h"
#include "JBootLoader.h"
#include "JBuiltinClassLoader.h"
#include "JClassLoader.h"
#include "JChartFactory.h"
#include "JXYSeries.h"
#include "JXYSeriesCollection.h"
#include "JChartUtilities.h"
#include "JJFreeChart.h"
#include "JPlot.h"
#include "JValueAxis.h"
#include "JTextTitle.h"
#include "JXYPlot.h"
#include "JNumberAxis.h"
#include "JXYLineAndShapeRenderer.h"
#include "JStandardXYToolTipGenerator.h"
#include "JXYItemRenderer.h"
#include "JPlotOrientation.h"
#include "JDatasetRenderingOrder.h"
#include "JCombinedDomainXYPlot.h"

static JavaVM* _vm = 0;
static JNIEnv* _env = 0;
static jobject _loader = 0;
static jobject _chart = 0;
static void CDspBDist5_doCreateChart(CDspBDist5* pThis);
static jobject createPlot(JNIEnv* env, CDspBDist5* pThis);
static jobject createPlot0(JNIEnv* env, jobject dataset0, jobject dataset1, jobject dataset2, double p);
static jobject createDataSet0(JNIEnv* env, char* key, int n, int* z);
static jobject createDataSet1(JNIEnv* env, char* key, int n, int* z);
static jobject createDataSet2(JNIEnv* env, char* key, int n, int* z, double px);
static void CDspBDist5_doWriteChartAsJPEG(CDspBDist5* pThis, char* fileName);
static void init();
static void end();
static void updModPth(char* modPth);
static void loadModules(JNIEnv* env, jobject cf, jobject clf);


static CDspBDist5 _cDspBDist5 = {
	.FP_createChart = CDspBDist5_doCreateChart,
	.FP_writeChartAsJPEG = CDspBDist5_doWriteChartAsJPEG,
};
CDspBDist5* getDspBDist5(char* modPth)
{
	CDspBDist5_ctor(&_cDspBDist5, modPth);
	return &_cDspBDist5;
}
void CDspBDist5_ctor(CDspBDist5* pThis, char* modPth)
{
	pThis->martin = malloc(sizeof(CMartinGale));
	init();
	updModPth(modPth);
}
void CDspBDist5_dtor(CDspBDist5* pThis)
{
	end();
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void CDspBDist5_createChart(CDspBDist5* pThis)
{
	assert(pThis != 0);
	pThis->FP_createChart(pThis);
}
void CDspBDist5_writeChartAsJPEG(CDspBDist5* pThis, char* fileName)
{
	assert(pThis != 0);
	pThis->FP_writeChartAsJPEG(pThis, fileName);
}
/**************************************/
/* �����¹���                         */
/**************************************/
static void CDspBDist5_doCreateChart(CDspBDist5* pThis)
{
	jobject title = JClass_StringNew(_env, "�ޥ���󥲡������θ���");
	char subTitle[64];
	sprintf(subTitle, "(�٥�̡������(p=0.45,0.5,0.55,n=%d)�η��)", pThis->n);
	jobject domainAxis = newNumberAxis(_env, _loader, "���");
	jobject plot = createPlot(_env, pThis );
	
	/*--- ���� ---*/
	JXYPlot_setDomainAxis(_env, plot, domainAxis);
	JValueAxis_setLowerMargin(_env, domainAxis, 0.03);
	JValueAxis_setUpperMargin(_env, domainAxis, 0.03);
	
	_chart = newJFreeChart(_env, _loader, title, plot);
	JJFreeChart_addSubtitle(_env, _chart, newTextTitle(_env, _loader, JClass_StringNew(_env, subTitle)));
}
static jobject createPlot(JNIEnv* env, CDspBDist5* pThis)
{
	CMartinGale* martin = pThis->martin;
	jobject plot = newCombinedDomainXYPlot(env, _loader, newNumberAxis(env, _loader, "���"));
	
	JCombinedDomainXYPlot_add(_env, plot, 
		createPlot0(env, 
			createDataSet0(env, "P0.45", pThis->n, martin->z045), 
			createDataSet1(env, "E0.45", pThis->n, martin->z045), 
			createDataSet2(env, "CE0.45", pThis->n, martin->z045, 0.45), 0.45)
		, 1);
	JCombinedDomainXYPlot_add(_env, plot, 
		createPlot0(env, 
			createDataSet0(env, "P0.50", pThis->n, martin->z050), 
			createDataSet1(env, "E0.50", pThis->n, martin->z050), 
			createDataSet2(env, "CE0.50", pThis->n, martin->z050, 0.50), 0.50)
		, 1);
	JCombinedDomainXYPlot_add(_env, plot, 
		createPlot0(env, 
			createDataSet0(env, "P0.55", pThis->n, martin->z055),
			createDataSet1(env, "E0.55", pThis->n, martin->z055), 
			createDataSet2(env, "E0.55", pThis->n, martin->z055, 0.55), 0.55),
		1);
	return plot;
}
static jobject createPlot0(JNIEnv* env, jobject dataset0, jobject dataset1, jobject dataset2, double p)
{
	jobject valueAxis0 = newNumberAxis(_env, _loader, "�������");
	jobject valueAxis1 = newNumberAxis(_env, _loader, "E");
	jobject valueAxis2 = newNumberAxis(_env, _loader, "CE");
	// Renderer
	jobject renderer0 = newXYLineAndShapeRenderer(_env, _loader, JNI_TRUE, JNI_FALSE); // XYItemRenderer renderer = new XYLineAndShapeRenderer(true, false);
	jobject renderer1 = newXYLineAndShapeRenderer(_env, _loader, JNI_TRUE, JNI_FALSE); // XYItemRenderer renderer = new XYLineAndShapeRenderer(true, false);
	jobject renderer2 = newXYLineAndShapeRenderer(_env, _loader, JNI_TRUE, JNI_FALSE); // XYItemRenderer renderer = new XYLineAndShapeRenderer(true, false);
	jobject generator = newStandardXYToolTipGenerator(_env, _loader);

	JXYItemRenderer_setBaseToolTipGenerator(_env, renderer0, generator);
	JXYItemRenderer_setBaseToolTipGenerator(_env, renderer1, generator);
	JXYItemRenderer_setBaseToolTipGenerator(_env, renderer2, generator);
	// XYPlot
	jobject plot = newXYPlot(env, _loader);
	
	JXYPlot_setOrientation(_env, plot, JPlotOrientation_VERTICAL(_env, _loader));
	JPlot_mapDatasetToRangeAxis(_env, plot, 0, 0);
	JPlot_mapDatasetToRangeAxis(_env, plot, 1, 1);
	JPlot_mapDatasetToRangeAxis(_env, plot, 2, 2);
	JPlot_setDatasetRenderingOrder(_env, plot, JDatasetRenderingOrder_FORWARD(_env, _loader));
	
	/*--- �ļ� ---*/
	JXYPlot_setRangeAxis(_env, plot, 0, valueAxis0);
	JXYPlot_setDataset(_env, plot, 0, dataset0);
	JXYPlot_setRenderer(_env, plot, 0, renderer0);

	JXYPlot_setRangeAxis(_env, plot, 1, valueAxis1);
	JXYPlot_setDataset(_env, plot, 1, dataset1);
	JXYPlot_setRenderer(_env, plot, 1, renderer1);
	JValueAxis_setLowerBound(_env, valueAxis1, -1 * p);
	JValueAxis_setUpperBound(_env, valueAxis1, p);
	JValueAxis_setTickUnit(_env, _loader, valueAxis1, 0.1);
	JValueAxis_setNumberFormatOverride(_env, valueAxis1, "0.0#");
	
	JXYPlot_setRangeAxis(_env, plot, 2, valueAxis2);
	JXYPlot_setDataset(_env, plot, 2, dataset2);
	JXYPlot_setRenderer(_env, plot, 2, renderer2);
	JValueAxis_setLowerBound(_env, valueAxis2, 0.0);
	JValueAxis_setUpperBound(_env, valueAxis2, 1.0);
	JValueAxis_setTickUnit(_env, _loader, valueAxis2, 0.2);
	JValueAxis_setNumberFormatOverride(_env, valueAxis2, "0.0#");
	
	return plot;
}
static jobject createDataSet0(JNIEnv* env, char* key, int n, int* z)
{
	int i;
	int cntMartin = 0;
	jobject p = newXYSeries(env, _loader, JClass_StringNew(_env, key));
	
	for (i = 0; i < n; i++) {
		JXYSeries_add(env, p, i, cntMartin);
		cntMartin += z[i];
	}
	
	jobject series = newXYSeriesCollection(env, _loader);
	JXYSeriesCollection_addSeries(env, series, p);
	return series;
}
static jobject createDataSet1(JNIEnv* env, char* key, int n, int* z)
{
	jobject e = newXYSeries(env, _loader, JClass_StringNew(_env, key));
	int i;
	int cnty = 0;
	
	for (i = 0; i < n; i++) {
		if (1 == z[i]) {
			cnty++;
		}
		double py = cnty / (i + 1.0);
		double qy = 1.0 - py;
		
		JXYSeries_add(env, e, i, py - qy);
	}
	
	jobject series = newXYSeriesCollection(env, _loader);
	JXYSeriesCollection_addSeries(env, series, e);
	return series;
}
static jobject createDataSet2(JNIEnv* env, char* key, int n, int* z, double px)
{
	double qx = 1.0 - px;
	jobject e = newXYSeries(env, _loader, JClass_StringNew(_env, key));
	int i;
	int cnty = 0;
	double by = 0.0;
	
	for (i = 0; i < n; i++) {
		if (1 == z[i]) {
			cnty++;
		}
		double py = cnty / (i + 1.0);
		double qy = 1.0 - py;
		
		JXYSeries_add(env, e, i, by + py - qy);
		by = (1 == z[i]) ? py : qy;
	}
	jobject series = newXYSeriesCollection(env, _loader);
	JXYSeriesCollection_addSeries(env, series, e);
	return series;
}
static void CDspBDist5_doWriteChartAsJPEG(CDspBDist5* pThis, char* fileName)
{
	JChartUtilities_writeChartAsJPEG(_env, _loader, JClass_StringNew(_env, fileName), _chart, 1000, 600);
}


static JavaVMOption jvmOpts[] = {
	{.optionString = "-XX:+UnlockExperimentalVMOptions", .extraInfo=NULL}
	,{.optionString = "-XX:+EnableJVMCI", .extraInfo=NULL}
	
};
static JavaVMInitArgs vm_args = {
	.version = JNI_VERSION_1_8,
	.nOptions = NSIZE(jvmOpts),
	.options = jvmOpts
};
static void init()
{
	JNI_CreateJavaVM(&_vm, (void **)&_env, (void *)&vm_args);
	
}
static void end()
{
	assert(_vm != NULL);
	(*_vm)->DestroyJavaVM(_vm);
}
static void updModPth(char* modPth)
{
	jobject jmodPath = JPaths_get(_env, modPth);
	jobject mfinder = JModuleFinder_of(_env, jmodPath);
	jobject refs = JModuleFinder_findAll(_env, mfinder);
	jobject iteObj = JSet_iterator(_env, refs);
	
	jobject roots = newSet(_env);
	while(JNI_TRUE == JIterator_hasNext(_env, iteObj)) {
		jobject mref = JIterator_next(_env, iteObj);          // ModuleReference
		jobject mdesc = JModuleReference_descriptor(_env, mref); // ModuleDescriptor
		jstring jdescName = JModuleDescriptor_name(_env, mdesc);
		
		JSet_add(_env, roots, jdescName);
	}
	/*
     *    ModuleFinder finder = ModuleFinder.of(dir1, dir2, dir3);
	 *    ModuleLayer bootLayer = ModuleLayer.boot();
     *    Configuration parent = bootLayer.configuration();
     *    Configuration cf = parent.resolve(finder, ModuleFinder.of(new Path[0]), Set.of("myapp"));
	 *    Function<String, ClassLoader> clf = ModuleLoaderMap.mappingFunction(cf);
     *    ModuleBootstrap.loadModules(cf, clf);
     *        for (ResolvedModule resolvedModule : cf.modules()) {
     *            ModuleReference mref = resolvedModule.reference();
     *            String name = resolvedModule.name();
     *            ClassLoader loader = clf.apply(name);
     *            if (loader == null) {
     *               // skip java.base as it is already loaded
     *               if (!name.equals(JAVA_BASE)) {
     *                   BootLoader.loadModule(mref);
     *               }
     *            } else if (loader instanceof BuiltinClassLoader) {
     *                ((BuiltinClassLoader) loader).loadModule(mref);
     *            }
     *        }
	 */
	jobject bootLayer = JModuleLayer_boot(_env);
	jobject parent = JModuleLayer_configuration(_env, bootLayer);
	jobject cf = JConfiguration_resolveAndBind(_env, parent, mfinder, JModuleFinder_of(_env, 0), roots);
	jobject clf = JModuleLoaderMap_mappingFunction(_env, cf);
	
	loadModules(_env, cf, clf);
	jobject emptyM = JModuleLayer_defineModules(_env, bootLayer, cf, clf);
	// ���ܸ줬ʸ���������ʤ��ơ���
	_loader = JModuleLayer_findLoader(_env, emptyM, JClass_StringNew(_env,"jfreechart"));  // ClassLoader jdbc = emptyM.findLoader("jfreechart")
	JChartFactory_setChartTheme(_env, _loader);
}
static void loadModules(JNIEnv* env, jobject cf, jobject clf)
{
	jobject reslvedMs = JConfiguration_modules(env, cf);
	jobject iteObj = JSet_iterator(env, reslvedMs);

	while(JNI_TRUE == JIterator_hasNext(env, iteObj)) {
		jobject resolvedModule = JIterator_next(env, iteObj);          // ResolvedModule
		jobject mref = JResolvedModule_reference(env, resolvedModule); // ModuleReference
		jstring name = JResolvedModule_name(env, resolvedModule);
		jobject loader = JFunction_apply(env, clf, name);

		if (0 == loader) {
			const char* _name = JClass_GetStringUTFChars(env, name);
			
			if (0 != strcmp("java.base", _name)) {
				JBootLoader_loadModule(env, mref);
			}
		} else if (JNI_TRUE == JClass_IsInstanceOf(env, loader, JClass_FindClass(env, "jdk/internal/loader/BuiltinClassLoader"))) {
			JBuiltinClassLoader_loadModule(env, loader, mref);
		}
	}
}
