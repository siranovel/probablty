#ifndef _JXYLineAndShapeRenderer_H_
#define _JXYLineAndShapeRenderer_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
/**************************************/
/* define�錾                         */
/**************************************/
#define XYLineAndShapeRenderer "org.jfree.chart.renderer.xy.XYLineAndShapeRenderer"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject newXYLineAndShapeRenderer(JNIEnv* env, jobject loader, jboolean lines, jboolean shapes);
#endif
