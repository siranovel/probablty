#include <stdio.h>
#include <assert.h>
#include "JXYLineAndShapeRenderer.h"
#include "JClassLoader.h"

static jobject doNewXYLineAndShapeRenderer(JNIEnv* env, jobject loader, jboolean lines, jboolean shapes);
jobject newXYLineAndShapeRenderer(JNIEnv* env, jobject loader, jboolean lines, jboolean shapes)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXYLineAndShapeRenderer(env, loader, lines, shapes);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXYLineAndShapeRenderer(JNIEnv* env, jobject loader, jboolean lines, jboolean shapes)
{
	jvalue argValues[] = {
		[0] = { .z = lines},
		[1] = { .z = shapes},
	};
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XYLineAndShapeRenderer));
	return JClass_NewObjectA(env, clz, "(ZZ)V", argValues);
}
