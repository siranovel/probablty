#include <stdio.h>
#include <assert.h>
#include "JRectangleEdge.h"
#include "JClassLoader.h"


static jobject JRectangleEdge_doTOP(JNIEnv* env, jobject loader);
static jobject JRectangleEdge_doBOTTOM(JNIEnv* env, jobject loader);
static jobject JRectangleEdge_doLEFT(JNIEnv* env, jobject loader);
static jobject JRectangleEdge_doRIGHT(JNIEnv* env, jobject loader);
static JRectangleEdge _jPosition = {
	.FP_TOP    = JRectangleEdge_doTOP,
	.FP_BOTTOM = JRectangleEdge_doBOTTOM,
	.FP_LEFT   = JRectangleEdge_doLEFT,
	.FP_RIGHT  = JRectangleEdge_doRIGHT,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JRectangleEdge_TOP(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jPosition.FP_TOP(env, loader);
}
jobject JRectangleEdge_BOTTOM(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jPosition.FP_BOTTOM(env, loader);
}
jobject JRectangleEdge_LEFT(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jPosition.FP_LEFT(env, loader);
}
jobject JRectangleEdge_RIGHT(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return _jPosition.FP_RIGHT(env, loader);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JRectangleEdge_doTOP(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,RectangleEdge));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "TOP", "Lorg/jfree/ui/RectangleEdge;");
	return JClass_GetStaticObjectField(env, clz, fid);
}
static jobject JRectangleEdge_doBOTTOM(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,RectangleEdge));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "BOTTOM", "Lorg/jfree/ui/RectangleEdge;");
	return JClass_GetStaticObjectField(env, clz, fid);
}
static jobject JRectangleEdge_doLEFT(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,RectangleEdge));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "LEFT", "Lorg/jfree/ui/RectangleEdge;");
	return JClass_GetStaticObjectField(env, clz, fid);
}
static jobject JRectangleEdge_doRIGHT(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,RectangleEdge));
	jfieldID fid = JClass_GetStaticFieldID(env, clz, "RIGHT", "Lorg/jfree/ui/RectangleEdge;");
	return JClass_GetStaticObjectField(env, clz, fid);
}
