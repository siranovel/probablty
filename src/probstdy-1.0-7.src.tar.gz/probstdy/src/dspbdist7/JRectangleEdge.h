#ifndef _JRectangleEdge_H_
#define _JRectangleEdge_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JRectangleEdge JRectangleEdge;

struct _JRectangleEdge
{
	jobject (*FP_TOP)(JNIEnv* env, jobject loader);
	jobject (*FP_BOTTOM)(JNIEnv* env, jobject loader);
	jobject (*FP_LEFT)(JNIEnv* env, jobject loader);
	jobject (*FP_RIGHT)(JNIEnv* env, jobject loader);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define RectangleEdge "org.jfree.ui.RectangleEdge"
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
jobject JRectangleEdge_TOP(JNIEnv* env, jobject loader);
jobject JRectangleEdge_BOTTOM(JNIEnv* env, jobject loader);
jobject JRectangleEdge_LEFT(JNIEnv* env, jobject loader);
jobject JRectangleEdge_RIGHT(JNIEnv* env, jobject loader);
#endif
