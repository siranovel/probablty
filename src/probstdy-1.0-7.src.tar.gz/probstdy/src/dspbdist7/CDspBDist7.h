#ifndef _CDspBDist7_H_
#define _CDspBDist7_H_

#include "CBlackSholes.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _CDspBDist7 CDspBDist7;

struct _CDspBDist7
{
	int n;
	CBlackSholes bs[20];
	void (*FP_createChart)(CDspBDist7* pThis);
	void (*FP_writeChartAsJPEG)(CDspBDist7* pThis, char* fileName);
};
/**************************************/
/* define�錾                         */
/**************************************/
#define NSIZE(a) (sizeof(a) / sizeof(a[0]))
#define N 600
#define NTIME(a) NSIZE(a)
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
CDspBDist7* getDspBDist7(char* modPth);
void CDspBDist7_ctor(CDspBDist7* pThis, char* modPth);
void CDspBDist7_dtor(CDspBDist7* pThis);
void CDspBDist7_createChart(CDspBDist7* pThis);
void CDspBDist7_writeChartAsJPEG(CDspBDist7* pThis, char* fileName);
#endif
