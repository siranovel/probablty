#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "CDspBDist7.h"


static void usage(char* exeNm);
void dspbdist7(CDspBDist7* pThis);
void calc(CDspBDist7* pThis);
int getRandom(int min, int max);
int main(int argc, char* argv[])
{
	if (2 > argc) {
		usage(argv[0]);
		exit(0);
	}
	
	char* updModPth = argv[1];
	CDspBDist7* pThis = getDspBDist7(updModPth);
	
	pThis->n = N;
	if (3 == argc) {
		sscanf(argv[2], "%d", &pThis->n);
	}
	if (0 >= pThis->n) {
		usage(argv[0]);
		exit(0);
	}
	dspbdist7(pThis);
	CDspBDist7_dtor(pThis);
    return 0;
}
static void usage(char* exeNm)
{
	printf("Usage:\n");
	printf("%s <JFreeChart Module Path> | ｲn", exeNm);
	printf("\n");
	printf("\t0 < 回数default:%d\n", N);
}
void dspbdist7(CDspBDist7* pThis)
{
	calc(pThis);
	CDspBDist7_createChart(pThis);
	CDspBDist7_writeChartAsJPEG(pThis, "blackScholes.jpg");
}
void calc(CDspBDist7* pThis)
{
	int i;
	int j;
	const int sz = sizeof(int) * pThis->n;
	
	srand(time(0));
	for (i = 0; i < NTIME(pThis->bs); i++) {
		CBlackSholes*     bs = &pThis->bs[i];

		bs->z05 = malloc(sz);
		memset(bs->z05, 0, sz);
		int* z05 = bs->z05;
		for(j = 0; j < pThis->n; j++) {
			int rnd = getRandom(0, 99);
			
			z05[j] = -1;
			if(50 > rnd) {
				z05[j] = 1;
			}
		}
	}
}

int getRandom(int min, int max)
{
	return min + (int)(rand() * (max - min + 1.0) / (1.0 + RAND_MAX));
}
