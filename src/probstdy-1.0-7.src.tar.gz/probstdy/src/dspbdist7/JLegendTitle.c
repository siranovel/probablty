#include <stdio.h>
#include <assert.h>
#include "JLegendTitle.h"


static void JLegendTitle_doSetPosition(JNIEnv* env, jobject legend, jobject position);
static JLegendTitle _jLegend = {
	.FP_setPosition = JLegendTitle_doSetPosition,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JLegendTitle_setPosition(JNIEnv* env, jobject legend, jobject position)
{
	assert(env != 0);
	assert(legend != 0);
	assert(position != 0);
	
	_jLegend.FP_setPosition(env, legend, position);
}
/**************************************/
/* �������s��                         */
/**************************************/
static void JLegendTitle_doSetPosition(JNIEnv* env, jobject legend, jobject position)
{
	jvalue argValues[] = {
		[0] = { .l = position},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, legend), "setPosition", "(Lorg/jfree/ui/RectangleEdge;)V");
	JClass_CallVoidMethodA(env, legend, mid, argValues);
}
