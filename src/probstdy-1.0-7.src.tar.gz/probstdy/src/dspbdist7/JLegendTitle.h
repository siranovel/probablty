#ifndef _JLegendTitle_H_
#define _JLegendTitle_H_

#include "JClass.h"
/**************************************/
/* �\���̐錾                         */
/**************************************/
typedef struct _JLegendTitle JLegendTitle;

struct _JLegendTitle
{
	void (*FP_setPosition)(JNIEnv* env, jobject legend, jobject position);
};
/**************************************/
/* define�錾                         */
/**************************************/
/**************************************/
/* �v���g�^�C�v�錾                   */
/**************************************/
void JLegendTitle_setPosition(JNIEnv* env, jobject legend, jobject position);
#endif
