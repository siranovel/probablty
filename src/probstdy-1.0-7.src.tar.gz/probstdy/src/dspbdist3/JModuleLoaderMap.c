#include <stdio.h>
#include <assert.h>
#include "JModuleLoaderMap.h"

static jobject JModuleLoaderMap_doMappingFunction(JNIEnv* env, jobject cf);
static JModuleLoaderMap _jModuleLoaderMap = {
	.FP_mappingFunction = JModuleLoaderMap_doMappingFunction,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jobject JModuleLoaderMap_mappingFunction(JNIEnv* env, jobject cf)
{
	return _jModuleLoaderMap.FP_mappingFunction(env, cf);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject JModuleLoaderMap_doMappingFunction(JNIEnv* env, jobject cf)
{
	assert(cf != 0);
	jvalue argValues[] = {
		[0] = { .l = cf},
	};
	jclass clz = JClass_FindClass(env, "jdk/internal/module/ModuleLoaderMap");
	jmethodID mid = JClass_GetStaticMethodID(env, clz, "mappingFunction", "(Ljava/lang/module/Configuration;)Ljava/util/function/Function;");
	return JClass_CallStaticObjectMethodA(env, clz, mid, argValues);
}
