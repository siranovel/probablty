#include <stdio.h>
#include <assert.h>
#include "JModuleDescriptor.h"

static jstring JModuleDescriptor_doName(JNIEnv *env, jobject mdesc);
static JModuleDescriptor _jModuleDescriptor = {
	.FP_name = JModuleDescriptor_doName,
};
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
jstring JModuleDescriptor_name(JNIEnv *env, jobject mdesc)
{
	assert(env != 0);
	return _jModuleDescriptor.FP_name(env, mdesc);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jstring JModuleDescriptor_doName(JNIEnv *env, jobject mdesc)
{
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, mdesc), "name", "()Ljava/lang/String;");
	
	return JClass_CallObjectMethodA(env, mdesc, mid, NULL);;
}
