#include <stdio.h>
#include <assert.h>
#include "JXYSeriesCollection.h"
#include "JClassLoader.h"

static jobject doNewXYSeriesCollection(JNIEnv* env, jobject loader);
static void JXYSeriesCollection_doAddSeries(JNIEnv* env, jobject seriesColl, jobject series);
static JXYSeriesCollection _jXYSeriesCollection = {
	.FP_addSeries = JXYSeriesCollection_doAddSeries,
};
jobject newXYSeriesCollection(JNIEnv* env, jobject loader)
{
	assert(env != 0);
	assert(loader != 0);
	return doNewXYSeriesCollection(env, loader);
}
/**************************************/
/* InterFface��                       */
/**************************************/
/**************************************/
/* Class��                            */
/**************************************/
void JXYSeriesCollection_addSeries(JNIEnv* env, jobject seriesColl, jobject series)
{
	assert(env != 0);
	assert(seriesColl != 0);
	assert(series != 0);
	
	_jXYSeriesCollection.FP_addSeries(env, seriesColl, series);
}
/**************************************/
/* �������s��                         */
/**************************************/
static jobject doNewXYSeriesCollection(JNIEnv* env, jobject loader)
{
	jclass  clz = JClassLoader_loadClass(env, loader, JClass_StringNew(env,XYSeriesCollection));
	
	return JClass_NewObjectA(env, clz, "()V", 0);
}
static void JXYSeriesCollection_doAddSeries(JNIEnv* env, jobject seriesColl, jobject series)
{
	jvalue argValues[] = {
		[0] = { .l = series},
	};
	jmethodID mid = JClass_GetMethodID(env, 
		JClass_GetObjectClass(env, seriesColl), "addSeries", "(Lorg/jfree/data/xy/XYSeries;)V");
	
	JClass_CallVoidMethodA(env, seriesColl, mid, argValues);
}
